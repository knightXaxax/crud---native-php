
    <script src="public/vendor/jquery/jquery-3.4.1.js"></script>
    <script src="public/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="public/js/load_details.js"></script>
    <script src="public/js/app.js"></script>
</body>
</html>