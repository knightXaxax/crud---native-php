<?php
include 'pages/header.php';
?>
<title>Crud Functions | Registration</title>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="row content">
                <div class="col-lg-3 col-md-2 col-sm-1"></div>
                <div class="col-lg-6 col-md-8 col-sm-10 py-4 my-4">
                    <?php include 'forms/registration_form.php' ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include 'pages/footer.php';
?>